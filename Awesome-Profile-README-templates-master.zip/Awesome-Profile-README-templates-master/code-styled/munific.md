# Hello, Im Ethan!

- 𝗜 𝗮𝗺 𝗮 𝗽𝗿𝗼𝗴𝗿𝗮𝗺𝗺𝗲𝗿 𝗶𝗻 𝗵𝗶𝗴𝗵 𝘀𝗰𝗵𝗼𝗼𝗹
- 𝗜 ❤️ 𝗟𝗼𝘄 𝗟𝗲𝘃𝗲𝗹 𝗣𝗿𝗼𝗴𝗿𝗮𝗺𝗺𝗶𝗻𝗴!

```julia
module main

aboutMe :: struct {
  pronouns :: string[];
  languages :: string[];
  hobbies :: string[];
  funFact :: string;
}

main :: func(): void {
  ethan :: aboutMe = {
    pronouns: ["He", "Him"],
    languages: ["C", "C#", "Java", "Python"],
    hobbies: ["Coding", "Gaming", "Talking"],
    funFact: "The first computer virus was created in 1983!"
  };

  println "Pronouns: ${ethan.pronouns}";
  println "Languages I Know: ${ethan.languages}";
  println "My Hobbies: ${ethan.hobbies}";
  println "Fun Fact: ${ethan.funFact}";
}
```

## 𝗪𝗵𝗮𝘁 𝗜 𝗨𝘀𝗲

<table>
  <tbody>
    <tr valign="top">
      <td width="25%" align="center">
        <span>𝗖</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/c.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗖#</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/c-sharp.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗝𝗮𝘃𝗮</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/java.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗣𝘆𝘁𝗵𝗼𝗻</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/python.svg">
      </td>
    </tr>
    <tr valign="top">
      <td width="25%" align="center">
        <span>𝗦𝘂𝗯𝗹𝗶𝗺𝗲 𝗧𝗲𝘅𝘁 𝟯</span><br><br><br>
        <img height="64px" src="https://cdn.worldvectorlogo.com/logos/sublime-text.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗚𝗶𝘁</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/git-icon.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗩𝗶𝘀𝘂𝗮𝗹 𝗦𝘁𝘂𝗱𝗶𝗼 𝗖𝗼𝗱𝗲</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/visual-studio-code.svg">
      </td>
    </tr>
  </tbody>
</table>

# 𝗖𝘂𝗿𝗿𝗲𝗻𝘁𝗹𝘆 𝘄𝗼𝗿𝗸𝗶𝗻𝗴 𝗼𝗻

- 💻 [Sadie Programming Language](https://github.com/sadie-lang/Sadie)


# 𝗠𝘆 𝗦𝘁𝗮𝘁𝘀

![Github stats](https://github-readme-stats.vercel.app/api?username=munific&show_icons=true&hide_border=true)

# 𝗪𝗵𝗮𝘁 𝘄𝗶𝗹𝗹 𝗶 𝗱𝗼 𝘁𝗵𝗶𝘀 𝘄𝗲𝗲𝗸
I have achieved:
- Write a tokenizer for [Sadie-lang](https://github.com/sadie-lang/Sadie)

## Show ❤️ By Starring My Repos!


# Other
Sadie-lang Discord:

![Discord](https://img.shields.io/discord/731577337686130858?label=Join%20The%20DIscord%21&logo=Sadie%20Lang&style=for-the-badge)

---

 ⭐️ From [munific](https://github.com/munific)
