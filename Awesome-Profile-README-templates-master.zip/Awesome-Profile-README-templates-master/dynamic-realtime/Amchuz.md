<p align="center">
  <img src="https://github.com/Amchuz/Amchuz/blob/master/Amchuz.gif">
</p>
  
.
  
  
### 👋 Hello World !  <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Earth.gif" width="24px">
  
:heart: Programming | :black_heart: K-pop | :blue_heart: Anime
  
I am a Final Year Computer Engineering Student at College of Engineering Chengannur. I love Machine Learning and trying to find more about Full Stack Web Development and Cyber Security. 

- 🔭 I’m currently working on Sign Language Translator to Malayalam Application using Flutter and Python.
- 🌱 I’m currently learning Data Science | Full Stack Web development | App Development | NLP | Cyber Security
- 👯 I’m looking to collaborate on Machine Learning and Web Development Projects <img src="https://media.giphy.com/media/WUlplcMpOCEmTGBtBW/giphy.gif" width="30">
- 💬 Ask me about anything. I will try to help you as much as I can.
- ⚡ Quote: There is always time. You just have to find it.
- 📫 How to reach me:

| [<img src="https://raw.githubusercontent.com/Delta456/Delta456/master/img/github.png" alt="github logo" width="34">](https://github.com/Amchuz) |  [<img src="https://raw.githubusercontent.com/Delta456/Delta456/master/img/dev.png" alt="dev logo" width="24">](https://dev.to/amchuz) |  [<img src="https://raw.githubusercontent.com/Delta456/Delta456/master/img/twitter.png" alt="twitter logo" width="34">](https://twitter.com/PrifyPhilip) |  [<img src="https://raw.githubusercontent.com/Delta456/Delta456/master/img/gitlab.png" alt="gitlab logo" width="24">](https://gitlab.com/Amchuz) |  [<img src="https://github.com/Amchuz/Amchuz/blob/master/linkedin.jpeg" alt="linkedin logo" width="24">](https://www.linkedin.com/in/prify-philip-343b53150/) |  [<img src="https://github.com/Amchuz/Amchuz/blob/master/gmail.jpeg" alt="gmail logo" width="24">](amchu1714@gmail.com)
|---|---|---|---|---|---|

----

#### <img src="https://media.giphy.com/media/VgCDAzcKvsR6OM0uWg/giphy.gif" width="50"> How about some stats ?
  
.    
   
![Prify Philip's GitHub Stats](https://github-readme-stats.vercel.app/api?username=Amchuz&hide=["stars"]&show_icons=true)

-------

📊 **Weekly development breakdown**
<!--START_SECTION:waka-->
```text
Python      4 hrs 32 mins       █████████░░░░░░░░░░░░░░░░   35.69 
HTML/CSS    2 hrs 50 mins       █████░░░░░░░░░░░░░░░░░░░░   22.32 
Javascript  1 hr 10 mins        ██░░░░░░░░░░░░░░░░░░░░░░░   9.17 
Dart        1 hr 5 mins         ██░░░░░░░░░░░░░░░░░░░░░░░   8.61 


⭐️ From [@Amchuz](https://github.com/Amchuz)
