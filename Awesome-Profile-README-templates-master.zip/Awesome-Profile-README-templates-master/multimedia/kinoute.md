<p align="center">
  <img src="https://github.com/kinoute/kinoute/blob/master/images/output.gif?raw=true" />
<em>Mariko Kaga in "<a href="https://www.imdb.com/title/tt0056327">Kawaita hana</a>" (1964).</em>
</p>

⭐️ From [kinoute](https://github.com/kinoute)
