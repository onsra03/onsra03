<h1 align="center">
  <img src="https://ik.imagekit.io/dfw3q47dv0/the_power_of_dark_side_fPLL-vX6C.gif" />
</h1>

## 👋 Hello, visitor! May The Force be with you!



I'm a 41 year old Electronic Engineer from São Paulo, Brazil and I'm studying to become a **Full Stack Developer** at **Rocketseat School**. I'm currently looking for opportunities. I love to learn and contribute in any and every possible way. I'm passionate about technology, people, theather and specialy movies, as well as you've been noticed, I'm a huge fan of Star Wars.

- 🌱 I’m currently learning the stack Node.js | ReactJS | React Native.
- 💬 Ask me about Javascript / TypeScript, Node.js/Express.js, Docker, SOLID and so on.
- 📫 How to reach me: [twitter](https://twitter.com/JoseMontagnana), [Email](jrenato78@gmail.com), [LinkedIn](https://www.linkedin.com/in/joserenato-devfullstack/)
- 😄 Pronouns: he/him/his

---

⭐ From [jose-renato-m](https://github.com/jose-renato-m)