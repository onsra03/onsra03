<p align="center">
  <img src="https://i.imgur.com/IyjFcq1.png" width="200px">
  <br>
  <samp>
    Hello, I'm Jon! 👋
    Software Engineer Intern at Mekari<br>
    :school: Sophomore at University of Indonesia<br>
    :sparkles: Favorite Tech: React, Typescript, GraphQL, Postgres ... <br>
    :notebook: I’m currently learning CS <br>
    :email:	jojonicho181@gmail.com <br>
    :art: Portfolio: https://jojonicho.wtf <br>
    :pencil: Resume: https://cv.jojonicho.wtf <br>
    :briefcase: LinkedIn: https://linkedin.com/in/joni <br>
    Image Artist: https://ansqee.netlify.app <br>
    :notes: Aimer, Mrs. GREEN APPLE, Kenshi Yonezu <br>
  </samp>
</p>

⭐️ From [jojonicho](https://github.com/jojonicho)
