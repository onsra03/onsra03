<!--
Hi! This is an easter egg.
Congratulations you found the first one!
-->

[![Matrix SVG](https://raw.githubusercontent.com/rodrigograca31/rodrigograca31/master/matrix.svg)](https://www.youtube.com/watch?v=SDkAGkd4NLc)

<!-- # 👀 Hi stranger! 👋🏻 -->

# 🤔 About me:

- 🐇 Following the white rabbit
- 🐈 Cat dad 😻
- Professional 🐛 solver
- 👨🏻‍💻 Full-Stack Developer
- 💊 Coding the Matrix
- 😍 Emoji lover
- 🚀 One day I will see humans on Mars!
- 🐇🥚 There's easter eggs in this profile...

<!-- Watch this: https://www.youtube.com/watch?v=eC7xzavzEKY -->

---

👇🏻 Here is a list of the Open Source projects I work on: 👇🏻


⭐️ From [rodrigograca31](https://github.com/rodrigograca31)
