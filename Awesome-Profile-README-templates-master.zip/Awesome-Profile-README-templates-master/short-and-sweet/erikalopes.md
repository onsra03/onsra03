<h1 align="center"> 🤩 hello, i'm Erika Lopes 🤩 </h1>
<h3 align="center">🚀 fullstack devlover 🚀</h3>

<img src="https://yata-apix-a9caea66-ad78-425f-aa08-e292558ebb65.lss.locawebcorp.com.br/b7c7dbff38ae4f419c94ce8d2254b9d9.png"> 

### 💻 my favorite stack:
- React Native ❤
- ReactJS & Styled-Components
- NodeJS & Express
- A little PHP
- HTML & CSS

### 👧 a little about myself:
- I'm 20 years old., and I live in Ceará, BR.
- I study information systems in Faculdade de Juazeiro do Norte.
- I'm a little too addicted to coffee.

<img src="https://yata-apix-a9caea66-ad78-425f-aa08-e292558ebb65.lss.locawebcorp.com.br/b7c7dbff38ae4f419c94ce8d2254b9d9.png"> 

<h1 align="center">
✨ where you can find me ✨
  
  <p align="center"><br/>
   <a href="https://www.linkedin.com/in/erika-lopes/">
    <img src="https://img.shields.io/badge/linkedin-erika--lopes-blue">
  </a>
  
  <a href="https://www.instagram.com/erika.cafezin/">
    <img src="https://img.shields.io/badge/instagram-erika.cafezin-red">
  </a>
</p>
</h1>

<h3 align="center"><strong> feel free to look at my experiment lab. ❤ </strong> </h3>
